import sample.model.Livro;

public class Main {

    public static void main(String[] args) {

        Livro livro = new Livro();

        livro.setTitulo("Senhor dos Anéis");
        System.out.println("Titulo: " + livro.getTitulo());

        livro.setAutor("J. R. R. Tolkien");
        System.out.println("Autor: " + livro.getAutor());
        livro.setEditora("Allen & Unwin");
        System.out.println("Editora: " + livro.getEditora());
        livro.setAno(2002);
        System.out.println("Ano:" + livro.getAno());

        System.out.println("\n\n" + livro);

    }


}
